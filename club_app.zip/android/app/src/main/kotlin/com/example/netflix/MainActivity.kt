package com.example.movie

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
