class KeywordEntity {
  KeywordEntity({
    required this.name,
    required this.id,
  });

  final String ? name;
  final int ? id;

}